class Cadastro{
    constructor(nome, sobrenome, email, telefone) {

        this.nome = nome,
        this.sobrenome = sobrenome,
        this.email =  email,
        this.telefone = telefone

        }
        get cadastrar(){

                return `Nome: ${this.nome} ${this.sobrenome}`
    
        }
        get mostrar(){
               
                return `Nome: ${this.cadastrar} \n Email: ${this.email} \n Tel: ${this.telefone}`
        }

}

const listaConvidados = document.getElementById("convidados")




function inserirConvidado() {

        //Me ajuda á resolver a falsa interpretação de campos vazios

        const nome = document.getElementById("nome").value
        const sobrenome = document.getElementById("sobrenome").value
        const email = document.getElementById("email").value
        const telefone = document.getElementById("telefone").value
        
        this.nome = nome,
        this.sobrenome = sobrenome,
        this.email =  email,
        this.telefone = telefone    

        const taVazio = [this.nome, this.sobrenome, this.email, this.telefone].includes(undefined)

        this.taVazio = taVazio

        console.log(`
	\n Os campos estão vazios? ${this.taVazio}
        \n Valores Recebidos abaixo:   
	\n --> Nome: ${this.nome}
	\n --> Sobrenome: ${this.sobrenome} 
	\n --> Email: ${this.email}
        \n -->Telefone: ${this.telefone}
        `)
        
        if(this.taVazio == false){  

        const cadastro = new Cadastro(nome, sobrenome, email, telefone)
        const option = document.createElement("option")
        option.text = cadastro.mostrar

        listaConvidados.add(option)

        //impressão de ajuda
        console.log("Pegou o if mas lembra de pedir ajuda com o parametro=false que deveria ser (true) mas com true dá erro e não pega o if (Erro:  pega quando tem campos vazios) ")

        }
        else if((this.nome = null) ||(this.sobrenome = null) ||(this.email = null) |(this.telefone = null)){
                alert("Pegou o (else if) Algum campo Vazio!")
        }

        else{
                alert(" Pegou o else. tem bug!")
        }

        // return (this.taVazio ? `
	// \n Os campos estão vazios? ${this.taVazio}
        // \n Valores Recebidos abaixo:   
	// \n --> Nome: ${this.nome}
	// \n --> Sobrenome: ${this.sobrenome} 
	// \n --> Email: ${this.email}
        // \n -->Telefone: ${this.telefone}
        // ` 
        // : `Não inserir convidados com campos Vazios!`)
}


function removerConvidado() {
        const index = listaConvidados.selectedIndex
        if (index != -1) {
                listaConvidados.remove(index)
        }
}
