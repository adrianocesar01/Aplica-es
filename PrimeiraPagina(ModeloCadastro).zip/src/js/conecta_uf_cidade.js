(function(){

   // const uf_nasc = document.querySelector('select[id=uf_nasc]').value
    const option_id =  document.querySelector("option[id]").value
    const list_state_id = [document.querySelectorAll("cities[id]").value]

   // if((uf_nasc && option_id) == state_id)/*referenciar id do cidades_por_uf.json*/
   if(option_id == option_id.value)
    {
        return([list_state_id])
       
    }
})();