document.addEventListener('DOMContentLoaded', function () {

     const ifrm = document.createElement("iframe")

     ifrm.setAttribute("allowFullScreen", true)
     ifrm.setAttribute("height", 600)
     ifrm.setAttribute("width", 1200)

     ifrm.removeAttribute("sandbox")
     ifrm.removeAttribute("about:blank")

     const teste = function () {
          ifrm.setAttribute("src", `https://sinalpublico.com/player3/server19hlb.php?vid=QNTMLEPCNTRMPST01EP${ep}`)
          document.getElementsByClassName('player')[0].appendChild(ifrm)
     }

     const btn01 = document.querySelector('button[id="btn01"]')
     const btn02 = document.querySelector('button[id="btn02"]')
     const btn03 = document.querySelector('button[id="btn03"]')
     const btn04 = document.querySelector('button[id="btn04"]')
     const btn05 = document.querySelector('button[id="btn05"]')
     const btn06 = document.querySelector('button[id="btn06"]')
     const btn07 = document.querySelector('button[id="btn07"]')
     const btn08 = document.querySelector('button[id="btn08"]')
     const btn09 = document.querySelector('button[id="btn09"]')
     const btn10 = document.querySelector('button[id="btn10"]')
     const btn11 = document.querySelector('button[id="btn11"]')
     const btn12 = document.querySelector('button[id="btn12"]')
     const btn13 = document.querySelector('button[id="btn13"]')
     const btn14 = document.querySelector('button[id="btn14"]')
     const btn15 = document.querySelector('button[id="btn15"]')
     const btn16 = document.querySelector('button[id="btn16"]')
     const btn17 = document.querySelector('button[id="btn17"]')
     const btn18 = document.querySelector('button[id="btn18"]')

     btn01.addEventListener('click', function () {
          ep = "01"
          teste(ep)
     })

     btn02.addEventListener('click', function () {
          ep = "02"
          teste(ep)
     })

     btn03.addEventListener('click', function () {
          ep = "03"
          teste(ep)
     })

     btn04.addEventListener('click', function () {
          ep = "04"
          teste(ep)
     })

     btn05.addEventListener('click', function () {
          ep = "05"
          teste(ep)
     })

     btn06.addEventListener('click', function () {
          ep = "06"
          teste(ep)
     })

     btn07.addEventListener('click', function () {
          ep = "07"
          teste(ep)
     })

     btn08.addEventListener('click', function () {
          ep = "08"
          teste(ep)
     })

     btn09.addEventListener('click', function () {
          ep = "09"
          teste(ep)
     })

     btn10.addEventListener('click', function () {
          ep = "10"
          teste(ep)
     })

     btn11.addEventListener('click', function () {
          ep = "11"
          teste(ep)
     })

     btn12.addEventListener('click', function () {
          ep = "12"
          teste(ep)
     })

     btn13.addEventListener('click', function () {
          ep = "13"
          teste(ep)
     })

     btn14.addEventListener('click', function () {
          ep = "14"
          teste(ep)
     })

     btn15.addEventListener('click', function () {
          ep = "15"
          teste(ep)
     })

     btn16.addEventListener('click', function () {
          ep = "16"
          teste(ep)
     })

     btn17.addEventListener('click', function () {
          ep = "17"
          teste(ep)
     })

     btn18.addEventListener('click', function () {
          ep = "18"
          teste(ep)
     })
})