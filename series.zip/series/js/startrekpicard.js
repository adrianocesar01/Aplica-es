document.addEventListener('DOMContentLoaded', function () {

    const ifrm = document.createElement("iframe")

    ifrm.setAttribute("allowFullScreen", true)
    ifrm.setAttribute("height", 600)
    ifrm.setAttribute("width", 1200)

    ifrm.removeAttribute("sandbox")
    ifrm.removeAttribute("about:blank")

    const server8 = function () {
        ifrm.setAttribute("src", `https://sinalpublico.com/player3/server8http2hlb.php?vid=STRTRKPCRDT${temp}EP${ep}`)
        document.getElementsByClassName('player')[0].appendChild(ifrm)
    }

    const server16 = function () {
        ifrm.setAttribute("src", `https://sinalpublico.com/player3/server16hlb.php?vid=STRTRKPCRDT${temp}EP${ep}`)
        document.getElementsByClassName('player')[0].appendChild(ifrm)
    }

    const server19 = function () {
        ifrm.setAttribute("src", `https://sinalpublico.com/player3/server19hlb.php?vid=STRTRKPCRDT${temp}EP${ep}`)
        document.getElementsByClassName('player')[0].appendChild(ifrm)
    }

    const server14 = function () {
        ifrm.setAttribute("src", `https://sinalpublico.com/player3/server14hlb.php?vid=STRTRKPCRDT${temp}EP${ep}`)
        document.getElementsByClassName('player')[0].appendChild(ifrm)
    }

    const btn01 = document.querySelector('button[id="btn01"]')
    const btn02 = document.querySelector('button[id="btn02"]')
    const btn03 = document.querySelector('button[id="btn03"]')
    const btn04 = document.querySelector('button[id="btn04"]')
    const btn05 = document.querySelector('button[id="btn05"]')
    const btn06 = document.querySelector('button[id="btn06"]')
    const btn07 = document.querySelector('button[id="btn07"]')
    const btn08 = document.querySelector('button[id="btn08"]')
    const btn09 = document.querySelector('button[id="btn09"]')
    const btn10 = document.querySelector('button[id="btn10"]')
    const btn11 = document.querySelector('button[id="btn11"]')
    const btn12 = document.querySelector('button[id="btn12"]')
    const btn13 = document.querySelector('button[id="btn13"]')
    const btn14 = document.querySelector('button[id="btn14"]')
    const btn15 = document.querySelector('button[id="btn15"]')
    const btn16 = document.querySelector('button[id="btn16"]')
    const btn17 = document.querySelector('button[id="btn17"]')
    const btn18 = document.querySelector('button[id="btn18"]')
    const btn19 = document.querySelector('button[id="btn19"]')
    const btn20 = document.querySelector('button[id="btn20"]')
    const btn21 = document.querySelector('button[id="btn21"]')
    const btn22 = document.querySelector('button[id="btn22"]')
    const btn23 = document.querySelector('button[id="btn23"]')
    const btn24 = document.querySelector('button[id="btn24"]')
    const btn25 = document.querySelector('button[id="btn25"]')
    const btn26 = document.querySelector('button[id="btn26"]')
    const btn27 = document.querySelector('button[id="btn27"]')
    const btn28 = document.querySelector('button[id="btn28"]')
    const btn29 = document.querySelector('button[id="btn29"]')
    const btn30 = document.querySelector('button[id="btn30"]')


    const corbtn01 = btn01.style.backgroundColor
    const corbtn02 = btn02.style.backgroundColor
    const corbtn03 = btn03.style.backgroundColor
    const corbtn04 = btn04.style.backgroundColor
    const corbtn05 = btn05.style.backgroundColor
    const corbtn06 = btn06.style.backgroundColor
    const corbtn07 = btn07.style.backgroundColor
    const corbtn08 = btn08.style.backgroundColor
    const corbtn09 = btn09.style.backgroundColor
    const corbtn10 = btn10.style.backgroundColor
    const corbtn11 = btn11.style.backgroundColor
    const corbtn12 = btn12.style.backgroundColor
    const corbtn13 = btn13.style.backgroundColor
    const corbtn14 = btn14.style.backgroundColor
    const corbtn15 = btn15.style.backgroundColor
    const corbtn16 = btn16.style.backgroundColor
    const corbtn17 = btn17.style.backgroundColor
    const corbtn18 = btn18.style.backgroundColor
    const corbtn19 = btn19.style.backgroundColor
    const corbtn20 = btn20.style.backgroundColor
    const corbtn21 = btn21.style.backgroundColor
    const corbtn22 = btn22.style.backgroundColor
    const corbtn23 = btn23.style.backgroundColor
    const corbtn24 = btn24.style.backgroundColor
    const corbtn25 = btn25.style.backgroundColor
    const corbtn26 = btn26.style.backgroundColor
    const corbtn27 = btn27.style.backgroundColor
    const corbtn28 = btn28.style.backgroundColor
    const corbtn29 = btn29.style.backgroundColor
    const corbtn30 = btn30.style.backgroundColor

    // btn01.style.backgroundColor = corbtn01
    // btn02.style.backgroundColor = corbtn02
    // btn03.style.backgroundColor = corbtn03
    // btn04.style.backgroundColor = corbtn04
    // btn05.style.backgroundColor = corbtn05
    // btn06.style.backgroundColor = corbtn06
    // btn07.style.backgroundColor = corbtn07
    // btn08.style.backgroundColor = corbtn08
    // btn09.style.backgroundColor = corbtn09
    // btn10.style.backgroundColor = corbtn10
    // btn11.style.backgroundColor = corbtn11
    // btn12.style.backgroundColor = corbtn12
    // btn13.style.backgroundColor = corbtn13
    // btn14.style.backgroundColor = corbtn14
    // btn15.style.backgroundColor = corbtn15
    // btn16.style.backgroundColor = corbtn16
    // btn17.style.backgroundColor = corbtn17
    // btn18.style.backgroundColor = corbtn18
    // btn19.style.backgroundColor = corbtn19
    // btn20.style.backgroundColor = corbtn20
    // btn21.style.backgroundColor = corbtn21
    // btn22.style.backgroundColor = corbtn22
    // btn23.style.backgroundColor = corbtn23
    // btn24.style.backgroundColor = corbtn24
    // btn25.style.backgroundColor = corbtn25
    // btn26.style.backgroundColor = corbtn26
    // btn27.style.backgroundColor = corbtn27
    // btn28.style.backgroundColor = corbtn28
    // btn29.style.backgroundColor = corbtn29
    // btn30.style.backgroundColor = corbtn30


    btn01.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30

        temp = "01"
        ep = "01"
        server8(temp, ep)

    })

    btn02.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "01"
        ep = "02"
        server8(temp, ep)
    })

    btn03.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "01"
        ep = "03"
        server14(temp, ep)
    })

    btn04.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "01"
        ep = "04"
        server14(temp, ep)
    })

    btn05.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "01"
        ep = "05"
        server14(temp, ep)
    })

    btn06.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "01"
        ep = "06"
        server14(temp, ep)
    })



    btn07.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "01"
        ep = "07"
        server14(temp, ep)
    })

    btn08.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "01"
        ep = "08"
        server14(temp, ep)
    })

    btn09.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "01"
        ep = "09"
        server14(temp, ep)
    })

    btn10.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "01"
        ep = "10"
        server14(temp, ep)
    })




    btn11.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "02"
        ep = "01"
        server16(temp, ep)
    })

    btn12.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "02"
        ep = "02"
        server16(temp, ep)
    })



    btn13.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30

        temp = "02"
        ep = "03"
        server16(temp, ep)

    })

    btn14.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "02"
        ep = "04"
        server16(temp, ep)
    })

    btn15.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "02"
        ep = "05"
        server16(temp, ep)
    })

    btn16.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "02"
        ep = "06"
        server16(temp, ep)
    })

    btn17.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "02"
        ep = "07"
        server16(temp, ep)
    })

    btn18.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "02"
        ep = "08"
        server16(temp, ep)
    })



    btn19.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "02"
        ep = "09"
        server16(temp, ep)
    })

    btn20.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "02"
        ep = "10"
        server16(temp, ep)
    })




    btn21.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "03"
        ep = "01"
        server19(temp, ep)
    })

    btn22.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn12
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "03"
        ep = "02"
        server19(temp, ep)
    })

    btn23.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "03"
        ep = "03"
        server19(temp, ep)
    })

    btn24.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "03"
        ep = "04"
        server19(temp, ep)
    })


    btn25.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "03"
        ep = "05"
        server19(temp, ep)
    })

    btn26.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "03"
        ep = "06"
        server19(temp, ep)
    })

    btn27.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "03"
        ep = "07"
        server19(temp, ep)
    })

    btn28.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn29.style.backgroundColor = corbtn29
        btn30.style.backgroundColor = corbtn30
        temp = "03"
        ep = "08"
        server19(temp, ep)
    })


    btn29.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn12.style.backgroundColor = corbtn12
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn30.style.backgroundColor = corbtn30
        temp = "03"
        ep = "09"
        server19(temp, ep)
    })

    btn30.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn13.style.backgroundColor = corbtn13
        btn14.style.backgroundColor = corbtn14
        btn15.style.backgroundColor = corbtn15
        btn16.style.backgroundColor = corbtn16
        btn17.style.backgroundColor = corbtn17
        btn18.style.backgroundColor = corbtn18
        btn19.style.backgroundColor = corbtn19
        btn20.style.backgroundColor = corbtn20
        btn21.style.backgroundColor = corbtn21
        btn22.style.backgroundColor = corbtn22
        btn23.style.backgroundColor = corbtn23
        btn24.style.backgroundColor = corbtn24
        btn25.style.backgroundColor = corbtn25
        btn26.style.backgroundColor = corbtn26
        btn27.style.backgroundColor = corbtn27
        btn28.style.backgroundColor = corbtn28
        btn29.style.backgroundColor = corbtn29
        temp = "03"
        ep = "10"
        server19(temp, ep)
    })

})