document.addEventListener('DOMContentLoaded', function () {

    const ifrm = document.createElement("iframe")

    ifrm.setAttribute("allowFullScreen", true)
    ifrm.setAttribute("height", 600)
    ifrm.setAttribute("width", 1200)

    ifrm.removeAttribute("sandbox")
    ifrm.removeAttribute("about:blank")

    const t1 = function () {
        ifrm.setAttribute("src", `https://sinalpublico.com/player3/server8http2hlb.php?vid=CDE404T${temp}EP${ep}`)
        document.getElementsByClassName('player')[0].appendChild(ifrm)
    }


    const t2 = function () {
        ifrm.setAttribute("src", `https://sinalpublico.com/player3/server16hlb.php?vid=CDE404T${temp}EP${ep}`)
        document.getElementsByClassName('player')[0].appendChild(ifrm)
    }

    const btn01 = document.querySelector('button[id="btn01"]')
    const btn02 = document.querySelector('button[id="btn02"]')
    const btn03 = document.querySelector('button[id="btn03"]')
    const btn04 = document.querySelector('button[id="btn04"]')
    const btn05 = document.querySelector('button[id="btn05"]')
    const btn06 = document.querySelector('button[id="btn06"]')
    const btn07 = document.querySelector('button[id="btn07"]')
    const btn08 = document.querySelector('button[id="btn08"]')
    const btn09 = document.querySelector('button[id="btn09"]')
    const btn10 = document.querySelector('button[id="btn10"]')
    const btn11 = document.querySelector('button[id="btn11"]')
    const btn12 = document.querySelector('button[id="btn12"]')

    const corbtn01 = btn01.style.backgroundColor
    const corbtn02 = btn02.style.backgroundColor
    const corbtn03 = btn03.style.backgroundColor
    const corbtn04 = btn04.style.backgroundColor
    const corbtn05 = btn05.style.backgroundColor
    const corbtn06 = btn06.style.backgroundColor
    const corbtn07 = btn07.style.backgroundColor
    const corbtn08 = btn08.style.backgroundColor
    const corbtn09 = btn09.style.backgroundColor
    const corbtn10 = btn10.style.backgroundColor
    const corbtn11 = btn11.style.backgroundColor
    const corbtn12 = btn12.style.backgroundColor

    btn01.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12

        temp = "01"
        ep = "01"
        t1(temp, ep)

    })

    btn02.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        temp = "01"
        ep = "02"
        t1(temp, ep)
    })

    btn03.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        temp = "01"
        ep = "03"
        t1(temp, ep)
    })

    btn04.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        temp = "01"
        ep = "04"
        t1(temp, ep)
    })

    btn05.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        temp = "01"
        ep = "05"
        t1(temp, ep)
    })

    btn06.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        temp = "01"
        ep = "06"
        t1(temp, ep)
    })



    btn07.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        temp = "02"
        ep = "01"
        t2(temp, ep)
    })

    btn08.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        temp = "02"
        ep = "02"
        t2(temp, ep)
    })

    btn09.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        temp = "02"
        ep = "03"
        t2(temp, ep)
    })

    btn10.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn11.style.backgroundColor = corbtn11
        btn12.style.backgroundColor = corbtn12
        temp = "02"
        ep = "04"
        t2(temp, ep)
    })

    btn11.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn12.style.backgroundColor = corbtn12
        temp = "02"
        ep = "05"
        t2(temp, ep)
    })

    btn12.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn01
        btn02.style.backgroundColor = corbtn02
        btn03.style.backgroundColor = corbtn03
        btn04.style.backgroundColor = corbtn04
        btn05.style.backgroundColor = corbtn05
        btn06.style.backgroundColor = corbtn06
        btn07.style.backgroundColor = corbtn07
        btn08.style.backgroundColor = corbtn08
        btn09.style.backgroundColor = corbtn09
        btn10.style.backgroundColor = corbtn10
        btn11.style.backgroundColor = corbtn11
        temp = "02"
        ep = "06"
        t2(temp, ep)
    })
})