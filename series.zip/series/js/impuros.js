document.addEventListener('DOMContentLoaded', function () {

    const ifrm = document.createElement("iframe")
    ifrm.setAttribute("height", 600)
    ifrm.setAttribute("width", 1200)
    ifrm.setAttribute("allowFullScreen", true)
    
    const server8 = function () {
        ifrm.setAttribute("src", `https://sinalpublico.com/player3/server8http2hlb.php?vid=IMPRST${temp}EP${ep}`)  
        document.getElementsByClassName('player')[0].appendChild(ifrm)
    }
    
    const server21 = function () {
        ifrm.setAttribute("src", `https://sinalpublico.com/player3/server21hlb.php?vid=IMPRST${temp}EP${ep}`)
        document.getElementsByClassName('player')[0].appendChild(ifrm)
    }

    //primeira temporada
    const btn01 = document.querySelector('button[id="btn01"]')
    const btn02 = document.querySelector('button[id="btn02"]')
    const btn03 = document.querySelector('button[id="btn03"]')
    const btn04 = document.querySelector('button[id="btn04"]')
    const btn05 = document.querySelector('button[id="btn05"]')
    const btn06 = document.querySelector('button[id="btn06"]')
    const btn07 = document.querySelector('button[id="btn07"]')
    const btn08 = document.querySelector('button[id="btn08"]')
    const btn09 = document.querySelector('button[id="btn09"]')
    //segunda temporada
    const btn10 = document.querySelector('button[id="btn10"]')
    const btn11 = document.querySelector('button[id="btn11"]')
    const btn12 = document.querySelector('button[id="btn12"]')
    const btn13 = document.querySelector('button[id="btn13"]')
    const btn14 = document.querySelector('button[id="btn14"]')
    const btn15 = document.querySelector('button[id="btn15"]')
    const btn16 = document.querySelector('button[id="btn16"]')
    const btn17 = document.querySelector('button[id="btn17"]')
    const btn18 = document.querySelector('button[id="btn18"]')
    const btn19 = document.querySelector('button[id="btn19"]')
    const btn20 = document.querySelector('button[id="btn20"]')
    //terceira temporada
    const btn21 = document.querySelector('button[id="btn21"]')
    const btn22 = document.querySelector('button[id="btn22"]')
    const btn23 = document.querySelector('button[id="btn23"]')
    const btn24 = document.querySelector('button[id="btn24"]')
    const btn25 = document.querySelector('button[id="btn25"]')
    const btn26 = document.querySelector('button[id="btn26"]')
    const btn27 = document.querySelector('button[id="btn27"]')
    const btn28 = document.querySelector('button[id="btn28"]')
    const btn29 = document.querySelector('button[id="btn29"]')
    const btn30 = document.querySelector('button[id="btn30"]')
    //quarta temporada
    const btn31 = document.querySelector('button[id="btn31"]')
    const btn32 = document.querySelector('button[id="btn32"]')
    const btn33 = document.querySelector('button[id="btn33"]')
    const btn34 = document.querySelector('button[id="btn34"]')
    const btn35 = document.querySelector('button[id="btn35"]')
    const btn36 = document.querySelector('button[id="btn36"]')
    const btn37 = document.querySelector('button[id="btn37"]')
    const btn38 = document.querySelector('button[id="btn38"]')
    const btn39 = document.querySelector('button[id="btn39"]')
    const btn40 = document.querySelector('button[id="btn40"]')

    const corbtn = btn01.style.backgroundColor

    btn01.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "01"
        ep = "01"
        server8(temp, ep)
    })

    btn02.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "01"
        ep = "02"
        server8(temp, ep)
    })

    btn03.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "01"
        ep = "03"
        server8(temp, ep)
    })

    btn04.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "01"
        ep = "04"
        server8(temp, ep)
    })

    btn05.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "01"
        ep = "05"
        server8(temp, ep)
    })

    btn06.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "01"
        ep = "06"
        server8(temp, ep)
    })

    btn07.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "01"
        ep = "07"
        server8(temp, ep)
    })

    btn08.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "01"
        ep = "08"
        server8(temp, ep)
    })

    btn09.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "01"
        ep = "09"
        server8(temp, ep)
    })

    btn10.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "01"
        ep = "10"
        server8(temp, ep)
    })

    btn11.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "02"
        ep = "01"
        server8(temp, ep)
    })

    btn12.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "02"
        ep = "02"
        server8(temp, ep)
    })

    btn13.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "02"
        ep = "03"
        server8(temp, ep)
    })

    btn14.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "02"
        ep = "04"
        server8(temp, ep)
    })

    btn15.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "02"
        ep = "05"
        server8(temp, ep)
    })

    btn16.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "02"
        ep = "06"
        server8(temp, ep)
    })

    btn17.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "02"
        ep = "07"
        server8(temp, ep)
    })

    btn18.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "02"
        ep = "08"
        server8(temp, ep)
    })

    btn19.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "02"
        ep = "09"
        server8(temp, ep)
    })

    btn20.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "02"
        ep = "10"
        server8(temp, ep)
    })


    btn21.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "03"
        ep = "01"
        server8(temp, ep)
    })

    btn22.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "03"
        ep = "02"
        server8(temp, ep)
    })

    btn23.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "03"
        ep = "03"
        server8(temp, ep)
    })

    btn24.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "03"
        ep = "04"
        server8(temp, ep)
    })


    btn25.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "03"
        ep = "05"
        server8(temp, ep)
    })

    btn26.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "03"
        ep = "06"
        server8(temp, ep)
    })

    btn27.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "03"
        ep = "07"
        server8(temp, ep)
    })

    btn28.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "03"
        ep = "08"
        server8(temp, ep)
    })


    btn29.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "03"
        ep = "09"
        server8(temp, ep)
    })

    btn30.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "03"
        ep = "10"
        server8(temp, ep)

    })

    btn31.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "04"
        ep = "01"
        server21(temp, ep)
    })

    btn32.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "04"
        ep = "02"
        server21(temp, ep)
    })

    btn33.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "04"
        ep = "03"
        server21(temp, ep)
    })

    btn34.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "04"
        ep = "04"
        server21(temp, ep)
    })

    btn35.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "04"
        ep = "05"
        server21(temp, ep)
    })



    btn36.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "04"
        ep = "06"
        server21(temp, ep)
    })

    btn37.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "04"
        ep = "07"
        server21(temp, ep)
    })

    btn38.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "04"
        ep = "08"
        server21(temp, ep)
    })

    btn39.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn11.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn40.style.backgroundColor = corbtn
        temp = "04"
        ep = "09"
        server21(temp, ep)
    })

    btn40.addEventListener('click', function () {
        this.style.backgroundColor = "yellow"
        btn01.style.backgroundColor = corbtn
        btn02.style.backgroundColor = corbtn
        btn03.style.backgroundColor = corbtn
        btn04.style.backgroundColor = corbtn
        btn05.style.backgroundColor = corbtn
        btn06.style.backgroundColor = corbtn
        btn07.style.backgroundColor = corbtn
        btn08.style.backgroundColor = corbtn
        btn09.style.backgroundColor = corbtn
        btn10.style.backgroundColor = corbtn
        btn12.style.backgroundColor = corbtn
        btn13.style.backgroundColor = corbtn
        btn14.style.backgroundColor = corbtn
        btn15.style.backgroundColor = corbtn
        btn16.style.backgroundColor = corbtn
        btn17.style.backgroundColor = corbtn
        btn18.style.backgroundColor = corbtn
        btn19.style.backgroundColor = corbtn
        btn20.style.backgroundColor = corbtn
        btn21.style.backgroundColor = corbtn
        btn22.style.backgroundColor = corbtn
        btn23.style.backgroundColor = corbtn
        btn24.style.backgroundColor = corbtn
        btn25.style.backgroundColor = corbtn
        btn26.style.backgroundColor = corbtn
        btn27.style.backgroundColor = corbtn
        btn28.style.backgroundColor = corbtn
        btn29.style.backgroundColor = corbtn
        btn30.style.backgroundColor = corbtn
        btn31.style.backgroundColor = corbtn
        btn32.style.backgroundColor = corbtn
        btn33.style.backgroundColor = corbtn
        btn34.style.backgroundColor = corbtn
        btn35.style.backgroundColor = corbtn
        btn36.style.backgroundColor = corbtn
        btn37.style.backgroundColor = corbtn
        btn38.style.backgroundColor = corbtn
        btn39.style.backgroundColor = corbtn
        temp = "04"
        ep = "10"
        server21(temp, ep)
    })
})