document.addEventListener('DOMContentLoaded', async function(){

    const campo1 = document.getElementById('1')
    const campo2 = document.getElementById('2')
    const campo3 = document.getElementById('3')
    const campo4 = document.getElementById('4')
    const campo5 = document.getElementById('5')
    const campo6 = document.getElementById('6')
    const campo7 = document.getElementById('7')
    const campo8 = document.getElementById('8')
    const campo9 = document.getElementById('9')
    const campo10 = document.getElementById('10')
    const campo11 = document.getElementById('11')
    const campo12 = document.getElementById('12')
    const campo13 = document.getElementById('13')
    const campo14 = document.getElementById('14')
    const campo15 = document.getElementById('15')
    const campo16 = document.getElementById('16')
    const campo17 = document.getElementById('17')
    const campo18 = document.getElementById('18')
    const campo19 = document.getElementById('19')
    const campo20 = document.getElementById('20')
    const campo21 = document.getElementById('21')
    const campo22 = document.getElementById('22')
    const campo23 = document.getElementById('23')
    const campo24 = document.getElementById('24')
    const campo25 = document.getElementById('25')
    const campo26 = document.getElementById('26')
    const campo27 = document.getElementById('27')
    const campo28 = document.getElementById('28')
    const campo29 = document.getElementById('29')
    const campo30 = document.getElementById('30')
    const campo31 = document.getElementById('31')
    const campo32 = document.getElementById('32')
    const campo33 = document.getElementById('33')
    const campo34 = document.getElementById('34')
    const campo35 = document.getElementById('35')
    const campo36 = document.getElementById('36')
    const campo37 = document.getElementById('37')
    const campo38 = document.getElementById('38')
    const campo39 = document.getElementById('39')
    const campo40 = document.getElementById('40')
    const campo41 = document.getElementById('41')
    // const campo42 = document.getElementById('42')
    // const corpo_calendario = document.getElementById('corpo_calendario')
    
    const data = new Date()
    let mes =  data.getMonth()
    let mes_selecionado = getMes(mes)
    getDias(mes_selecionado)
     
    
    function getDias(mes_selecionado){
    
        const dias = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31]
    
        console.log(`Valor "mes_selecionado" recebido por getDias = ${mes_selecionado} \n **************************************`)
    
        const ano = data.getFullYear()
    
        const data_completa_primeiro_dia_deste_mes = new Date(ano, mes_selecionado)
        console.log(`Data completa do primeiro dia do mês selecionado | ${data_completa_primeiro_dia_deste_mes.toLocaleDateString()}`)
    
        var dia_da_semana_do_primeiro_dia_do_mes = data_completa_primeiro_dia_deste_mes.getDay()
        console.log(`Indice do dia da semana do primeiro dia do mês selecionado | ${dia_da_semana_do_primeiro_dia_do_mes}`)
    
        var x = data_completa_primeiro_dia_deste_mes.getMonth()
        console.log(`Indice do mês selecionado | ${x}`)
    
    switch(dia_da_semana_do_primeiro_dia_do_mes){
    
        case(dia_da_semana_do_primeiro_dia_do_mes = 0):
            campo1.innerHTML = dias[0]
            campo2.innerHTML = dias[1]
            campo3.innerHTML = dias[2]
            campo4.innerHTML = dias[3]
            campo5.innerHTML = dias[4]
            campo6.innerHTML = dias[5]
            campo7.innerHTML = dias[6]
            campo8.innerHTML = dias[7]
            campo9.innerHTML = dias[8]
            campo10.innerHTML = dias[9]
            campo11.innerHTML = dias[10]
            campo12.innerHTML = dias[11]
            campo13.innerHTML = dias[12]
            campo14.innerHTML = dias[13]
            campo15.innerHTML = dias[14]
            campo16.innerHTML = dias[15]
            campo17.innerHTML = dias[16]
            campo18.innerHTML = dias[17]
            campo19.innerHTML = dias[18]
            campo20.innerHTML = dias[19]
            campo21.innerHTML = dias[20]
            campo22.innerHTML = dias[21]
            campo23.innerHTML = dias[22]
            campo24.innerHTML = dias[23]
            campo25.innerHTML = dias[24]
            campo26.innerHTML = dias[25]
            campo27.innerHTML = dias[26]
            campo28.innerHTML = dias[27]
            //conferir se o fevereiro é em ano bissexto
            campo29.innerHTML = dias[28]
            if((x == 1)){
                campo30.innerHTML = ''}
                else{
                    campo30.innerHTML = dias[29]
                }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            if((x == 0)||( x == 2 )||( x == 4)||(x == 6 )||( x == 7)||(x == 9)||(x == 11)){
                campo31.innerHTML = dias[30]}
                else{
                    campo31.innerHTML = ''
                }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            campo32.innerHTML = ''
            campo33.innerHTML = ''
            campo34.innerHTML = ''
            campo35.innerHTML = ''
            campo36.innerHTML = ''
            campo37.innerHTML = ''
            campo38.innerHTML = ''
    
            // campo40.innerHTML = mesAtual
            console.log(`Dia da semana do primeiro dia deste mes: Domingo`)
            break
    
        case(dia_da_semana_do_primeiro_dia_do_mes = 1):
            campo1.innerHTML = ''
            campo2.innerHTML = dias[0]
            campo3.innerHTML = dias[1]
            campo4.innerHTML = dias[2]
            campo5.innerHTML = dias[3]
            campo6.innerHTML = dias[4]
            campo7.innerHTML = dias[5]
            campo8.innerHTML = dias[6]
            campo9.innerHTML = dias[7]
            campo10.innerHTML = dias[8]
            campo11.innerHTML = dias[9]
            campo12.innerHTML = dias[10]
            campo13.innerHTML = dias[11]
            campo14.innerHTML = dias[12]
            campo15.innerHTML = dias[13]
            campo16.innerHTML = dias[14]
            campo17.innerHTML = dias[15]
            campo18.innerHTML = dias[16]
            campo19.innerHTML = dias[14]
            campo20.innerHTML = dias[18]
            campo21.innerHTML = dias[19]
            campo22.innerHTML = dias[20]
            campo23.innerHTML = dias[21]
            campo24.innerHTML = dias[22]
            campo25.innerHTML = dias[23]
            campo26.innerHTML = dias[24]
            campo27.innerHTML = dias[25]
            campo28.innerHTML = dias[26]
            campo29.innerHTML = dias[27]
            //conferir se o fevereiro é em ano bissexto
            campo30.innerHTML = dias[28]
            if((x == 1)){
                campo31.innerHTML = ''}
                else{
                    campo31.innerHTML = dias[29]
                }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            if ((x == 0)||( x == 2 )||( x == 4)||(x = 6 )||( x == 7)||(x == 9)||(x == 11)){
            campo32.innerHTML = dias[30]}
            else{
                campo32.innerHTML = ''
            }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            campo33.innerHTML = ''
            campo34.innerHTML = ''
            campo35.innerHTML = ''
            campo36.innerHTML = ''
            campo37.innerHTML = ''
            campo38.innerHTML = ''
    
            console.log(`Dia da semana do primeiro dia deste mes: Segunda`)
            break
    
        case(dia_da_semana_do_primeiro_dia_do_mes = 2):
            campo1.innerHTML = ''
            campo2.innerHTML = ''
            campo3.innerHTML = dias[0]
            campo4.innerHTML = dias[1]
            campo5.innerHTML = dias[2]
            campo6.innerHTML = dias[3]
            campo7.innerHTML = dias[4]
            campo8.innerHTML = dias[5]
            campo9.innerHTML = dias[6]
            campo10.innerHTML = dias[7]
            campo11.innerHTML = dias[8]
            campo12.innerHTML = dias[9]
            campo13.innerHTML = dias[10]
            campo14.innerHTML = dias[11]
            campo15.innerHTML = dias[12]
            campo16.innerHTML = dias[13]
            campo17.innerHTML = dias[14]
            campo18.innerHTML = dias[15]
            campo19.innerHTML = dias[16]
            campo20.innerHTML = dias[17]
            campo21.innerHTML = dias[18]
            campo22.innerHTML = dias[19]
            campo23.innerHTML = dias[20]
            campo24.innerHTML = dias[21]
            campo25.innerHTML = dias[22]
            campo26.innerHTML = dias[23]
            campo27.innerHTML = dias[24]
            campo28.innerHTML = dias[25]
            campo29.innerHTML = dias[26]
            campo30.innerHTML = dias[27]
            //conferir se o fevereiro é em ano bissexto
            campo31.innerHTML = dias[28]
            if((x == 1)){
                campo32.innerHTML = ''}
                else{
                    campo32.innerHTML = dias[29]
                }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            if ((x == 0)||( x == 2 )||( x == 4)||(x == 6 )||( x == 7)||(x == 9)||(x == 11)){
            campo33.innerHTML = dias[30]}
            else{
                campo33.innerHTML = ''
            }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            campo34.innerHTML = ''
            campo35.innerHTML = ''
            campo36.innerHTML = ''
            campo37.innerHTML = ''
            campo38.innerHTML = ''
    
            console.log(`Dia da semana do primeiro dia deste mes: Terça`)
            break
    
        case(dia_da_semana_do_primeiro_dia_do_mes = 3):
            campo1.innerHTML = ''
            campo2.innerHTML = ''
            campo3.innerHTML = ''
            campo4.innerHTML = dias[0]
            campo5.innerHTML = dias[1]
            campo6.innerHTML = dias[2]
            campo7.innerHTML = dias[3]
            campo8.innerHTML = dias[4]
            campo9.innerHTML = dias[5]
            campo10.innerHTML = dias[6]
            campo11.innerHTML = dias[7]
            campo12.innerHTML = dias[8]
            campo13.innerHTML = dias[9]
            campo14.innerHTML = dias[10]
            campo15.innerHTML = dias[11]
            campo16.innerHTML = dias[12]
            campo17.innerHTML = dias[13]
            campo18.innerHTML = dias[14]
            campo19.innerHTML = dias[15]
            campo20.innerHTML = dias[16]
            campo21.innerHTML = dias[17]
            campo22.innerHTML = dias[18]
            campo23.innerHTML = dias[19]
            campo24.innerHTML = dias[20]
            campo25.innerHTML = dias[21]
            campo26.innerHTML = dias[22]
            campo27.innerHTML = dias[23]
            campo28.innerHTML = dias[24]
            campo29.innerHTML = dias[25]
            campo30.innerHTML = dias[26]
            campo31.innerHTML = dias[27]
            //conferir se o fevereiro é em ano bissexto
            campo32.innerHTML = dias[28]
            if((x == 1)){
                campo33.innerHTML = ''}
                else{
                    campo33.innerHTML = dias[29]
                }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            if ((x == 0)||( x == 2 )||( x == 4)||(x == 6 )||( x == 7)||(x == 9)||(x == 11)){
            campo34.innerHTML = dias[30]}
            else{
                campo34.innerHTML = ''
            }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            campo35.innerHTML = ''
            campo36.innerHTML = ''
            campo37.innerHTML = ''
            campo38.innerHTML = ''
    
            console.log(`Dia da semana do primeiro dia deste mes: Quarta`)
            break
    
        case(dia_da_semana_do_primeiro_dia_do_mes = 4):
            campo1.innerHTML = ''
            campo2.innerHTML = ''
            campo3.innerHTML = ''
            campo4.innerHTML = ''
            campo5.innerHTML = dias[0]
            campo6.innerHTML = dias[1]
            campo7.innerHTML = dias[2]
            campo8.innerHTML = dias[3]
            campo9.innerHTML = dias[4]
            campo10.innerHTML = dias[5]
            campo11.innerHTML = dias[6]
            campo12.innerHTML = dias[7]
            campo13.innerHTML = dias[8]
            campo14.innerHTML = dias[9]
            campo15.innerHTML = dias[10]
            campo16.innerHTML = dias[11]
            campo17.innerHTML = dias[12]
            campo18.innerHTML = dias[13]
            campo19.innerHTML = dias[14]
            campo20.innerHTML = dias[15]
            campo21.innerHTML = dias[16]
            campo22.innerHTML = dias[17]
            campo23.innerHTML = dias[18]
            campo24.innerHTML = dias[19]
            campo25.innerHTML = dias[20]
            campo26.innerHTML = dias[21]
            campo27.innerHTML = dias[22]
            campo28.innerHTML = dias[23]
            campo29.innerHTML = dias[24]
            campo30.innerHTML = dias[25]
            campo31.innerHTML = dias[26]
            campo32.innerHTML = dias[27]
            //conferir se o fevereiro é em ano bissexto
            campo33.innerHTML = dias[28]
            if((x == 1)){
                campo34.innerHTML = ''}
                else{
                    campo34.innerHTML = dias[29]
                }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            if ((x == 0)||( x == 2 )||( x == 4)||(x == 6 )||( x == 7)||(x == 9)||(x == 11)){
                campo35.innerHTML = dias[30]}
                else{
                    campo35.innerHTML = ''
                }
               // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            campo36.innerHTML = ''
            campo37.innerHTML = ''
            campo38.innerHTML = ''
    
            console.log(`Dia da semana do primeiro dia deste mes: Quinta`)
            break
    
        case(dia_da_semana_do_primeiro_dia_do_mes = 5):
            campo1.innerHTML = ''
            campo2.innerHTML = ''
            campo3.innerHTML = ''
            campo4.innerHTML = ''
            campo5.innerHTML = ''
            campo6.innerHTML = dias[0]
            campo7.innerHTML = dias[1]
            campo8.innerHTML = dias[2]
            campo9.innerHTML = dias[3]
            campo10.innerHTML = dias[4]
            campo11.innerHTML = dias[5]
            campo12.innerHTML = dias[6]
            campo13.innerHTML = dias[7]
            campo14.innerHTML = dias[8]
            campo15.innerHTML = dias[9]
            campo16.innerHTML = dias[10]
            campo17.innerHTML = dias[11]
            campo18.innerHTML = dias[12]
            campo19.innerHTML = dias[13]
            campo20.innerHTML = dias[14]
            campo21.innerHTML = dias[15]
            campo22.innerHTML = dias[16]
            campo23.innerHTML = dias[17]
            campo24.innerHTML = dias[18]
            campo25.innerHTML = dias[19]
            campo26.innerHTML = dias[20]
            campo27.innerHTML = dias[21]
            campo28.innerHTML = dias[22]
            campo29.innerHTML = dias[23]
            campo30.innerHTML = dias[24]
            campo31.innerHTML = dias[25]
            campo32.innerHTML = dias[26]
            campo33.innerHTML = dias[27]
            //conferir se o fevereiro é em ano bissexto
            campo34.innerHTML = dias[28]
            if((x == 1)){
                campo35.innerHTML = ''}
                else{
                    campo35.innerHTML = dias[29]
                }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            if ((x == 0)||(x == 2)||(x == 4)||(x == 6)||(x == 7)||(x == 9)||(x == 11)){
                campo36.innerHTML = dias[30]}
            else{
                campo36.innerHTML = ''
            }
            console.log(`Indice do mês selecionado | ${x} | ${typeof(x)} `)
            campo37.innerHTML = ''
            campo38.innerHTML = ''
    
            console.log(`Dia desta semana do primeiro dia deste mes: Sexta`)
            break
    
        case(dia_da_semana_do_primeiro_dia_do_mes = 6):
            campo1.innerHTML = ''
            campo2.innerHTML = ''
            campo3.innerHTML = ''
            campo4.innerHTML = ''
            campo5.innerHTML = ''
            campo6.innerHTML = ''
            campo7.innerHTML = dias[0]
            campo8.innerHTML = dias[1]
            campo9.innerHTML = dias[2]
            campo10.innerHTML = dias[3]
            campo11.innerHTML = dias[4]
            campo12.innerHTML = dias[5]
            campo13.innerHTML = dias[6]
            campo14.innerHTML = dias[7]
            campo15.innerHTML = dias[8]
            campo16.innerHTML = dias[9]
            campo17.innerHTML = dias[10]
            campo18.innerHTML = dias[11]
            campo19.innerHTML = dias[12]
            campo20.innerHTML = dias[13]
            campo21.innerHTML = dias[14]
            campo22.innerHTML = dias[15]
            campo23.innerHTML = dias[16]
            campo24.innerHTML = dias[17]
            campo25.innerHTML = dias[18]
            campo26.innerHTML = dias[19]
            campo27.innerHTML = dias[20]
            campo28.innerHTML = dias[21]
            campo29.innerHTML = dias[22]
            campo30.innerHTML = dias[23]
            campo31.innerHTML = dias[24]
            campo32.innerHTML = dias[25]
            campo33.innerHTML = dias[26]
            campo34.innerHTML = dias[27]
            //conferir se o fevereiro é em ano bissexto
            campo35.innerHTML = dias[28]
            if((x == 1)){
                campo36.innerHTML = ''}
                else{
                    campo36.innerHTML = dias[29]
                }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            if ((x == 0)||( x == 2)||( x == 4)||(x == 6)||(x == 7)||(x == 9)||(x == 11)){
                campo37.innerHTML = dias[30]}
                else{
                    campo37.innerHTML = ''
                }
           // console.log(`Indice do mês selecionado | ${x} | ${typeof(x)}`)
            campo38.innerHTML = ''
    
            console.log(`Dia da semana do primeiro dia deste mes: Sábado`)
            break
    }}
    function getMes(mes){
    
        console.log(`Valor "mes" recebido por getMes = ${mes} \n **************************************`)
    
        switch(mes){
    
            case(mes = 0 /*'jan'*/):
                campo40.innerHTML = "Janeiro"
                console.log("Janeiro")
                return 0
        
            case(mes = 1 /*'fev'*/):
                campo40.innerHTML = "Fevereiro"
                console.log("Fevereiro")
                return 1
        
            case(mes = 2/*'mar'*/):
                campo40.innerHTML = "Março"
                console.log("Março")
                return 2
        
            case(mes = 3/*'abr'*/):
                campo40.innerHTML = "Abril"
                console.log("Abril")
                return 3
        
            case(mes = 4/*'mai'*/):
                console.log("Maio")
                campo40.innerHTML = "Maio"
                return 4
        
            case(mes = 5/*'jun'*/):
                campo40.innerHTML = "Junho"
                console.log("Junho")
                return 5
        
            case(mes = 6 /*'jul'*/):
                campo40.innerHTML = "Julho"
                console.log("Julho")
                return 6
        
            case(mes = 7 /*'ago'*/):
                campo40.innerHTML = "Agosto"
                console.log("Agosto")
                return 7
        
            case(mes = 8/*'set'*/):
                campo40.innerHTML = "Setembro"
                console.log("Setembro")
                return 8
        
            case(mes = 9 /*'out'*/):
                campo40.innerHTML = "Outubro"
                console.log("Outubro")
                return 9
        
            case(mes = 10 /*'nov'*/):
                campo40.innerHTML = "Novembro"
                console.log("Novembro")
                return 10
        
            case(mes = 11 /*'dez'*/):
                campo40.innerHTML = "Dezembro"
                console.log("Dezembro")
                return 11
    
            default: console.log(e => 'Passou direto!')
        }
    }    
        
    //Anterior
    campo39.addEventListener('click', async function(){
    
        let mes =  data.getMonth()-4
        let mes_selecionado = getMes(mes)
        console.log(`Valores dentro da função "Anterior" Mês Selecionado = ${mes_selecionado} | Mês = ${mes}`)
        getDias(mes_selecionado)
        // const indiceMesAnt = (element) => (element = (meses == (mes -1)))
        // const mesAnt = meses.findIndex(indiceMesAnt)
        // campo40.innerHTML = mesAnt
        // campo40.innerHTML =  (meses.indexOf = mesAtual-1)
    })
    //Proximo
    campo41.addEventListener('click', async function(){
        let mes = data.getMonth()+1
        let mes_selecionado = getMes(mes)
        console.log(`Valores dentro da função "Proximo" Mês Selecionado = ${mes_selecionado} | Mês = ${mes}`)
        getDias(mes_selecionado)
        // const indiceMesPro = (element) => (element = (meses == (mes +1)))
        // const mesPro = meses.findIndex(indiceMesPro)
        // campo40.innerHTML = mesPro
        // campo40.innerHTML =  (meses.indexOf = mesAtual+1)
    })
    })